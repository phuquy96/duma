import UIKit
import WebKit

class ViewController: UIViewController {

    private var webView: WKWebView!
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10
        config.timeoutIntervalForResource = 20
        config.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        return URLSession(configuration: config)
    }()

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black
        setupSecureWebView()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }

    private func setupSecureWebView() {
        let ucc = WKUserContentController()
        ucc.add(self, name: "nativeBridge")

        let cfg = WKWebViewConfiguration()
        cfg.userContentController = ucc
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []

        let wpp = WKWebpagePreferences()
        wpp.allowsContentJavaScript = true
        cfg.defaultWebpagePreferences = wpp

        webView = WKWebView(frame: view.bounds, configuration: cfg)
        webView.backgroundColor = UIColor.black
        webView.isOpaque = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = self
        webView.uiDelegate = self

        // Anti-Crack: Disable Web Inspector in production (iOS 16.4+)
        #if compiler(>=5.8)
        if #available(iOS 16.4, *) {
            webView.isInspectable = false
        }
        #endif

        view.addSubview(webView)

        // Load decrypted UI directly into WKWebView
        let htmlString = AppHTML.content
        webView.loadHTMLString(htmlString, baseURL: Bundle.main.bundleURL)
    }

    // Persistent Device HWID lock (anti-reset)
    private func getDeviceHWID() -> String {
        let key = "com.phuquy.0xjz1.hwid_v2"
        if let saved = UserDefaults.standard.string(forKey: key), !saved.isEmpty {
            return saved
        }
        let raw = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        let clean = raw.replacingOccurrences(of: "-", with: "").uppercased()
        let hwid = "PQ-" + clean.prefix(8)
        UserDefaults.standard.set(hwid, forKey: key)
        return hwid
    }
}

// MARK: - Navigation Delegate & Security Guard
extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView,
                 decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // Open external links in Safari (e.g. Telegram / Support)
        if action.navigationType == .linkActivated {
            if let url = action.request.url, url.scheme == "http" || url.scheme == "https" {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
}

// MARK: - UI Delegate (Alerts & Confirmations)
extension ViewController: WKUIDelegate {
    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: "0xjz1", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: "0xjz1", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "Đồng ý", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
}

// MARK: - Native Security Bridge
extension ViewController: WKScriptMessageHandler {
    func userContentController(_ ucc: WKUserContentController,
                                didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any],
              let action = body["action"] as? String else { return }

        switch action {

        case "getHWID":
            let hwid = getDeviceHWID()
            DispatchQueue.main.async { [weak self] in
                self?.eval("window.receiveNativeHWID('\(hwid)')")
            }

        case "httpGet":
            guard let urlStr = body["url"] as? String,
                  let cbId  = body["callbackId"] as? String,
                  let url   = URL(string: urlStr) else { return }

            // Anti-Crack: Validate that network requests strictly target trusted PHUQUY domains
            guard let host = url.host?.lowercased(), host.contains("severphuquy.sbs") else {
                DispatchQueue.main.async { [weak self] in
                    self?.eval("if(window['\(cbId)_e'])window['\(cbId)_e']('Chặn máy chủ không an toàn!')")
                }
                return
            }

            var req = URLRequest(url: url)
            req.setValue("application/json", forHTTPHeaderField: "Accept")
            req.setValue("PhuQuyAuth/2.0 (iOS; 0xjz1)", forHTTPHeaderField: "User-Agent")

            session.dataTask(with: req) { [weak self] data, _, error in
                DispatchQueue.main.async {
                    if let data = data,
                       let str = String(data: data, encoding: .utf8) {
                        let safe = str
                            .replacingOccurrences(of: "\\", with: "\\\\")
                            .replacingOccurrences(of: "'",  with: "\\'")
                            .replacingOccurrences(of: "\n", with: "\\n")
                            .replacingOccurrences(of: "\r", with: "")
                        self?.eval("window.receiveAPIResponse('\(cbId)','\(safe)')")
                    } else {
                        let err = error?.localizedDescription ?? "Lỗi kết nối máy chủ PHUQUY"
                        self?.eval("if(window['\(cbId)_e'])window['\(cbId)_e']('\(err)')")
                    }
                }
            }.resume()

        case "openURL":
            if let urlStr = body["url"] as? String,
               let url = URL(string: urlStr) {
                DispatchQueue.main.async {
                    UIApplication.shared.open(url)
                }
            }

        case "launchApp":
            // In-app launch handler
            break

        default:
            break
        }
    }

    private func eval(_ js: String) {
        webView.evaluateJavaScript(js, completionHandler: nil)
    }
}
